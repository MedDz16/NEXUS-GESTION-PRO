
# NEXUS GESTION PRO

Application Windows de gestion commerciale multi-activités.

## Version actuelle
Prototype d'interface (v0.1). Les chiffres affichés sont des valeurs de démonstration à zéro. Aucune vente, stock ou donnée réelle n'est encore enregistrée.

## Technologie
- C# / WPF
- .NET Framework 4.8
- Prévu pour une architecture client/serveur LAN
- PostgreSQL sera intégré dans une étape ultérieure

## Compilation
Ouvrir `NexusGestionPro.sln` avec Visual Studio sur Windows et compiler en Release.
Le workflow GitHub Actions permet également de compiler sur un runner Windows.

## Compatibilité
Windows 7 SP1 avec mises à jour nécessaires pour .NET Framework 4.8, Windows 8.1, Windows 10 et Windows 11. La compatibilité doit être validée par des tests sur chaque version.
