using System;
using System.Windows;

namespace NexusGestionPro
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DateText.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy");
        }
    }
}
