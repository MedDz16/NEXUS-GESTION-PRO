using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("NEXUS GESTION PRO")]
[assembly: AssemblyDescription("Gestion commerciale multi-activités")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("NEXUS")]
[assembly: AssemblyProduct("NEXUS GESTION PRO")]
[assembly: AssemblyCopyright("Copyright © NEXUS")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
