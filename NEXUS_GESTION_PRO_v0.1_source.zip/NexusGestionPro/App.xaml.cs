using System.Windows;
namespace NexusGestionPro
{
    public partial class App : Application { }
}
